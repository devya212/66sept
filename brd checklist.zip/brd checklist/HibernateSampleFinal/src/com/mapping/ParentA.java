package com.mapping;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class ParentA 
{
@Id
@GeneratedValue
private int parentId;

private String pName;
@OneToOne
private Passp pp;
@OneToMany
@JoinTable( name="chldB", 
joinColumns=@JoinColumn(name="parentA"), 
inverseJoinColumns=@JoinColumn(name="chlcol"))  
private List<ChildB> child=new ArrayList<ChildB>();
public int getParentId() {
	return parentId;
}
public void setParentId(int parentId) {
	this.parentId = parentId;
}
public String getpName() {
	return pName;
}
public void setpName(String pName) {
	this.pName = pName;
}
public List<ChildB> getChild() {
	return child;
}
public void setChild(List<ChildB> child) {
	this.child = child;
}
public Passp getPp() {
	return pp;
}
public void setPp(Passp pp) {
	this.pp = pp;
}
}
