package com.nucleus.aop;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;


@Component
@Aspect
public class AopLogger {
	static Logger log1=Logger.getLogger(AopLogger.class.getName());
	@Before("execution(* com.nucleus.dao.CustomerRDBMSDaoImpl.*(..))")
	public void start(JoinPoint point)
	{  
		log1.warn(point.getSignature().getName()+ "Started");
		
	}
	
	@After("execution(* com.nucleus.dao.CustomerRDBMSDaoImpl.*(..))")
	public void end(JoinPoint point)
	{
		log1.warn(point.getSignature().getName()+"Ended");
	}
	
	@Around("execution (* com.nucleus.dao.CustomerRDBMSDaoImpl.*(..))")
	public Object around(ProceedingJoinPoint process)throws Throwable
	{
		Object object=null;
		try
		{
			object=process.proceed();
			log1.warn(process.getSignature().getName()+"No Error");
		}
		catch(Throwable e)
		{
			log1.error(process.getSignature().getName()+"error \n");
		}
		return object;
	}

}