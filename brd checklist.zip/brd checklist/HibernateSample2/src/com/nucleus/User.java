package com.nucleus;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
@Entity
@Table(name="User3Sep")
//@Cacheable
//@Cache(usage=CacheConcurrencyStrategy.READ_ONLY)
@NamedQueries({@NamedQuery(name="query1",query="from user where userId= :par1")})
public class User 
{
@Id
@GeneratedValue
private int userId;
private String userName;
@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
private List<Address> adrs=new ArrayList<Address>();
public List<Address> getAdrs() {
	return adrs;
}
public void setAdrs(List<Address> adrs) {
	this.adrs = adrs;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
}
