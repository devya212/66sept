package com.nucleus;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test3 {

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction t=session.beginTransaction();
		User u=(User)session.get(com.nucleus.User.class, 2);
		User u2=(User)session.get(com.nucleus.User.class, 2);
		t.commit();session.close();
		Session session1=factory.openSession();
		Transaction t1=session1.beginTransaction();
		User u1=(User)session1.get(com.nucleus.User.class, 2);
		t1.commit();session1.close();

	}

}
