package com.nucleus;

import javax.persistence.Entity;

@Entity
public class Football extends Player
{
private int goals;

public int getGoals() {
	return goals;
}

public void setGoals(int goals) {
	this.goals = goals;
}
}
