package com.nucleus.pack6;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
@Entity
public class A {

@Id
private int aId;
private String aName;
@OneToMany(cascade=CascadeType.ALL)
@JoinColumn(name="newColumn")
//@JoinTable(name="a_bTable", joinColumns=@JoinColumn(name="colA"),inverseJoinColumns=@JoinColumn(name="colB"))
private List<B> bList=new ArrayList<B>();
public int getaId() {
	return aId;
}
public void setaId(int aId) {
	this.aId = aId;
}
public String getaName() {
	return aName;
}
public void setaName(String aName) {
	this.aName = aName;
}
public List<B> getbList() {
	return bList;
}
public void setbList(List<B> bList) {
	this.bList = bList;
}

}
