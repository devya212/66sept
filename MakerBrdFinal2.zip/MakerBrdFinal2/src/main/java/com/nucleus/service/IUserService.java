package com.nucleus.service;

import com.nucleus.model.User;

public interface IUserService {

	public void saveUser(User user, String[] role);
}