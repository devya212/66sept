package com.nucleus.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
//import javax.persistence.OneToMany;
//import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="user1010")
public class User implements Serializable {
	@Id
private String userid;
private String password;
private int checkEnable;
@ManyToMany
@JoinTable(name ="user10_role10", joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "userid"), inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "roleid"))
private List<Role> role;
public int getCheckEnable() {
	return checkEnable;
}
public void setCheckEnable(int checkEnable) {
	this.checkEnable = checkEnable;
}
public String getUserid() {
	return userid;
}
public void setUserid(String userid) {
	this.userid = userid;
}
public List<Role> getRole() {
	return role;
}
public void setRole(List<Role> role) {
	this.role = role;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
/*public Role getRole() {
	return role;
}
public void setRole(Role role) {
	this.role = role;
}*/
}