package com.nucleus.pack3;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
	Player p=new Player();
	Football f=new Football();
	Configuration cfg=new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory factory=cfg.buildSessionFactory();
	Session session=factory.openSession();
	Transaction t=session.beginTransaction();
	
	p.setpName("akash");
f.setpName("amit");
f.setTitle("Football player");
session.save(p);
session.save(f);
t.commit();session.close();
	}

}
