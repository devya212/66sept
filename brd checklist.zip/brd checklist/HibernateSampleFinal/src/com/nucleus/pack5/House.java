package com.nucleus.pack5;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

//import org.hibernate.annotations.Cache;
//import org.hibernate.annotations.CacheConcurrencyStrategy;
@Entity
//@Cacheable
//@Cache(usage =CacheConcurrencyStrategy.READ_ONLY)
@NamedQueries( {
@NamedQuery(query="from House where hId=:par",name="query1")}
)
public class House 
{
@Id
private int hId;
private String Address;
public int gethId() {
	return hId;
}
public void sethId(int hId) {
	this.hId = hId;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
@Override
public String toString() {
	return "House [hId=" + hId + ", Address=" + Address + "]";
}

}
