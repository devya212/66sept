package com.mapping;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class ChildB 
{
@Id
@GeneratedValue
private int childId;
private String cName;
public int getChildId() {
	return childId;
}
public void setChildId(int childId) {
	this.childId = childId;
}
public String getcName() {
	return cName;
}
public void setcName(String cName) {
	this.cName = cName;
}
}
