package com.mapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction t=session.beginTransaction();
		ChildB c1=new ChildB();
		c1.setcName("child one");
		
		ChildB c2=new ChildB();
		c2.setcName("child Two");
		
		ParentA p=new ParentA();
		p.setpName("zzz");
		p.getChild().add(c1);
		p.getChild().add(c2);
		Passp pp=new Passp();
		pp.setPpId(100);
		session.save(c1);
		session.save(c2);
		session.save(pp);
		p.setPp(pp);
		session.save(p);
		t.commit();
		session.close();
	}

}
