package com.nucleus.pack3;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value="Footballl")
public class Football extends Player
{
private String title;

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}
}
