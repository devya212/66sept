package com.nucleus;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction t=session.beginTransaction();
		Address a=new Address();
		Address a2=new Address();
		a.setCity("LKO");
		a.setState("UP");
		a2.setCity("KNP");
		a2.setState("UP");
		
		User u=new User();
		u.setUserName("abc");
		u.getAdrs().add(a);
		u.getAdrs().add(a2);
		session.save(u);
		//User u=(User)session.get(com.nucleus.User.class, 1);
		//List<Address> adrs=u.getAdrs();
		//System.out.println(u.getAdrs().size());
		t.commit();session.close();

	}

}
