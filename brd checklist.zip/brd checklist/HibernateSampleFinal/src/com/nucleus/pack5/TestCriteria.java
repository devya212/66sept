package com.nucleus.pack5;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

public class TestCriteria {

	public static void main(String[] args) 
	{
	Configuration cfg=new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory factory=cfg.buildSessionFactory();
	Session session=factory.openSession();
	Transaction t=session.beginTransaction();
	Criteria c=session.createCriteria(com.nucleus.pack5.House.class);
	c.add(Restrictions.between("hId", 10, 60));
//c.setProjection(Projections.property("hId"));
//c.setProjection(Projections.property("Address"));
	List l=c.list();
	Iterator it=l.iterator();
	while(it.hasNext())
	{
	House h=(House) it.next();
		System.out.println(h);
	}
	t.commit();
	session.close();
}
	

}
