package com.mapping;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Passp
{
@Id
private int ppId;

public int getPpId() {
	return ppId;
}

public void setPpId(int ppId) {
	this.ppId = ppId;
}
}
