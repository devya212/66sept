package com.nucleus.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
//import javax.persistence.OneToOne;

@Entity
@Table(name="role1010")


public class Role implements Serializable {
	@Id
private String roleid;
private String rolename;
@ManyToMany(mappedBy = "role")
private List<User> user;

public List<User> getUser() {
	return user;
}
public void setUser(List<User> user) {
	this.user = user;
}
public String getRoleid() {
	return roleid;
}
public void setRoleid(String roleid) {
	this.roleid = roleid;
}
public String getRolename() {
	return rolename;
}
public void setRolename(String rolename) {
	this.rolename = rolename;
}
}