package com.nucleus;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test1 {

	public static void main(String[] args) 
	{
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction t=session.beginTransaction();
		Player p=new Player();
		//Football f=new Football();
		Cricket c=new Cricket();
		p.setpName("Player name");
		c.setpName("cricket ");
		c.setWickets(4);
		session.save(c);
		session.save(p);
		t.commit();
		session.close();

	}

}
