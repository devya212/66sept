package com.nucleus.pack5;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestLanguage {

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction t=session.beginTransaction();
		
		Query q=session.createQuery("update House set address=:p1 where hId=:p");
		q.setParameter("p", new Integer(88));
		q.setParameter("p1", new String("new Address"));
		q.executeUpdate();
		/*List house= q.list();
		Iterator it=house.iterator();
		while(it.hasNext())
		{
			House house1=(House) it.next();
		System.out.println(house1.getAddress());
		}*/
		t.commit();session.close();

	}

}
