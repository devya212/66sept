package com.nucleus.pack6;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction t=session.beginTransaction();
		B ob1=new B();
		B ob2=new B();
		A obj=new A();
		ob1.setbId(1);
		ob2.setbId(2);
		obj.setaId(101);
		obj.getbList().add(ob1);
		obj.getbList().add(ob2);
		session.save(obj);
		t.commit();
		session.close();
	}

}
