package com.nucleus.pack5;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HQLSample {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction t=session.beginTransaction();
	//	House h=new House();
	//	h.sethId(112);
		//h.setAddress("Banaras");
		//session.save(h);
		
	House h=(House) session.get(com.nucleus.pack5.House.class, 10);
	h.setAddress("motinagar");
	session.update(h);
	h=(House) session.get(com.nucleus.pack5.House.class, 10);
	t.commit();
	System.out.println(h.getAddress());
	//h.setAddress("agra jaipur");
	//session.update(h);	t.commit();
	//h=(House) session.get(com.nucleus.pack5.House.class, 10);

	session.close();
	/*	Session session1=factory.openSession();
		Transaction t1=session1.beginTransaction();
		//House h1=(House) session1.get(com.nucleus.pack5.House.class, 10);
		House h1=new House();
		h1.sethId(890);
		h1.setAddress("Kanpur P road");
		session1.save(h1);
	t1.commit();
		session1.close();*/
	}

}
