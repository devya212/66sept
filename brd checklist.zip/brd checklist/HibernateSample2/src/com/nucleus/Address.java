package com.nucleus;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Address3Sep")
public class Address 
{
@Id
@GeneratedValue
private int aId;
private String city;
private String state;
public int getaId() {
	return aId;
}
public void setaId(int aId) {
	this.aId = aId;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}

}
