package com.nucleus.pack6;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class B {
	@Id
private int bId;
private String bName;

//private A aObj;
public int getbId() {
	return bId;
}
public void setbId(int bId) {
	this.bId = bId;
}
public String getbName() {
	return bName;
}
public void setbName(String bName) {
	this.bName = bName;
}

}
